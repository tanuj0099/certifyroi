// Firebase config - replace with your config from firebase.google.com
import { initializeApp } from 'firebase/app'
import { getAuth, GoogleAuthProvider } from 'firebase/auth'

const firebaseConfig = {
  // Your config here:
  apiKey: "xxx",
  authDomain: "xxx.firebaseapp.com",
  projectId: "xxx"
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const googleProvider = new GoogleAuthProvider()
export default app
